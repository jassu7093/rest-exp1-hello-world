// index.js
// A simple Node.js script to print Hello World

console.log("Hello World");
